//
//  GHEngine.h
//  Home Work OOP
//
//  Created by Sergey Zalozniy on 10/31/14.
//  Copyright (c) 2014 Sergey Zalozniy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GHEngine : NSObject

@property int horsePower; //мощность пример 150 л.с.
@property float capacity; //обьем пример - 2.0 литра

@end
