//
//  ViewController.h
//  HomeWork1
//
//  Created by admin on 23.10.14.
//  Copyright (c) 2014 Vika Vovk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

